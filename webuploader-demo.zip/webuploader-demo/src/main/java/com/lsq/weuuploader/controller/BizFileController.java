package com.lsq.weuuploader.controller;

import java.io.File;
import java.io.PrintWriter;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.commons.lang.math.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.lsq.webuploader.entity.BizFile;
import com.lsq.webuploader.service.BizFileService;
import com.lsq.webuploader.utils.DateUtil;

@Controller
public class BizFileController {
	
	@Autowired
	private BizFileService bizFileService;
	
	private JSONArray jsonArray;

	/**
	 *图片上传
	 * 
	 * @param id
	 * @param name
	 * @param flog
	 * @param autoId
	 * @param size
	 * @param type
	 * @param file
	 * @param request
	 */
	@RequestMapping(value = "fileUpload.do",method = RequestMethod.POST)
	@ResponseBody
	public String fileUpload(String id,String name,String size,String type, @RequestParam("file")MultipartFile file,HttpServletRequest request){
		try {
			//设置根目录
			String filePathGen = request.getSession().getServletContext()
					.getRealPath("/") + "upload/photoPhoto/" + "images";
			//进行上传并返回图片的绝对路径
			String ensourPath =  getEnourPath(request,file,filePathGen);
			
			//解析ensourPath
			String[] split = ensourPath.split("webapp");
			String string = split[1].substring(1, split[1].length());
			
			BizFile bizFile = new BizFile();
			bizFile.setSize(size);
			bizFile.setName(name);
			bizFile.setUrl(string);
			bizFile.setType(type);
			bizFile.setId(id);
			this.bizFileService.save(bizFile);
			return name;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	// 允许上传图片的格式
    private static final String[] IMAGE_TYPE = { ".jpg", ".jpge", ".bmp", ".png", "gif" };
	private String getEnourPath(HttpServletRequest request, MultipartFile file,String filePathGen) {
		 	Boolean flag = false;
		 	System.out.println(file.getOriginalFilename());
	        //校验图片格式
	        for (String type : IMAGE_TYPE) {
	            if (StringUtils.endsWithIgnoreCase(file.getOriginalFilename(), type)) {
	                flag = true;
	                break;
	            }
	        }
	        //如果图片校验错误，直接返回。
	        if (!flag) {
	            return "";
	        }
	      //生成图片的绝对路径
	        String filePath = getFilePath(request,file.getOriginalFilename(),filePathGen);

	        //创建File对象
	        File newfile = new File(filePath);

	        //把图片写入到磁盘中
	        try {
	        	file.transferTo(newfile);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		return filePath;
	}
	private String getFilePath(HttpServletRequest request,String originalFilename,String filePath) {
		new  DateUtil();
		String fileFolder = filePath + File.separator + DateUtil.getYear(new Date())
                + File.separator +  DateUtil.getMonth(new Date()) + File.separator
                + DateUtil.getDay(new Date());
		File file = new File(fileFolder);
        //如果文件目录不存在，则进行创建
        if (!file.isDirectory()) {
            file.mkdirs();
        }
        //生成图片的文件名
        String fileName = DateUtil._toDateString(new Date())
                + RandomUtils.nextInt(9999) + "."
                + StringUtils.substringAfterLast(originalFilename, ".");
        //拼接图片的路径
        return fileFolder + File.separator + fileName;
	}
	
	/**
	 * 回显获取文件：这里在mapper里默认取前4张（只是为了做回显效果，具体业务大家可以自己定义自己的逻辑）
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "getFiles.do")
	public List<BizFile> getFiles(HttpServletResponse resp){
		try {
			List<BizFile> list = this.bizFileService.queryList();
			return list;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}	
}

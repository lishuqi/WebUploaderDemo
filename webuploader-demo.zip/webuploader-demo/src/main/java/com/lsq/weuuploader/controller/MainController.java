package com.lsq.weuuploader.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainController {

	@RequestMapping("index.do")
	public String index(){
		return "index";
	}
	
	@RequestMapping("index2.do")
	public String index2(){
		return "index2";
	}
	
	@RequestMapping("index3.do")
	public String index3(){
		return "index3";
	}
	
	@RequestMapping("index4.do")
	public String index4(){
		return "index4";
	}
}

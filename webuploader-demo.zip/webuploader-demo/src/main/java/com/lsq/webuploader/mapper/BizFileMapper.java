package com.lsq.webuploader.mapper;

import java.util.List;

import com.lsq.webuploader.entity.BizFile;

public interface BizFileMapper {

	void save(BizFile bizFile);

	List<BizFile> queryList();

}

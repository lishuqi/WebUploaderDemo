package com.lsq.webuploader.service;

import java.util.List;

import com.lsq.webuploader.entity.BizFile;

public interface BizFileService {

	void save(BizFile bizFile)throws Exception;

	List<BizFile> queryList() throws Exception;

}
